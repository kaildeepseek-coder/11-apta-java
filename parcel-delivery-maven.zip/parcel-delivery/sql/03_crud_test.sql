USE parcel_delivery;
START TRANSACTION;

INSERT INTO senders (full_name, phone, city)
VALUES ('Тест Жіберуші', '87030000001', 'Тараз');
SET @sender_id = LAST_INSERT_ID();
SELECT * FROM senders WHERE id = @sender_id;
UPDATE senders SET city = 'Қарағанды' WHERE id = @sender_id;
SELECT * FROM senders WHERE id = @sender_id;

INSERT INTO recipients (full_name, phone, address)
VALUES ('Тест Алушы', '87030000002', 'Ақтөбе, Абай 12');
SET @recipient_id = LAST_INSERT_ID();
SELECT * FROM recipients WHERE id = @recipient_id;
UPDATE recipients SET address = 'Ақтөбе, Абай 15' WHERE id = @recipient_id;
SELECT * FROM recipients WHERE id = @recipient_id;

INSERT INTO statuses (name) VALUES ('Тест мәртебе');
SET @status_id = LAST_INSERT_ID();
SELECT * FROM statuses WHERE id = @status_id;
UPDATE statuses SET name = 'Тест мәртебе өзгерді' WHERE id = @status_id;
SELECT * FROM statuses WHERE id = @status_id;

INSERT INTO shipments (tracking_code, sender_id, recipient_id, status_id, description, weight_kg)
VALUES ('TEST-CRUD-001', @sender_id, @recipient_id, @status_id, 'Тест қорап', 1.50);
SET @shipment_id = LAST_INSERT_ID();
SELECT * FROM shipments WHERE tracking_code = 'TEST-CRUD-001';
UPDATE shipments SET tracking_code = 'TEST-CRUD-002', description = 'Өзгерген қорап', weight_kg = 2.00
WHERE id = @shipment_id;
SELECT * FROM shipments WHERE id = @shipment_id;

DELETE FROM shipments WHERE id = @shipment_id;
DELETE FROM statuses WHERE id = @status_id;
DELETE FROM recipients WHERE id = @recipient_id;
DELETE FROM senders WHERE id = @sender_id;

SELECT * FROM shipments WHERE id = @shipment_id;
SELECT * FROM statuses WHERE id = @status_id;
SELECT * FROM recipients WHERE id = @recipient_id;
SELECT * FROM senders WHERE id = @sender_id;
ROLLBACK;
