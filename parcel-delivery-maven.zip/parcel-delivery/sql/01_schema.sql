CREATE DATABASE IF NOT EXISTS parcel_delivery
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE parcel_delivery;

CREATE TABLE IF NOT EXISTS senders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    city VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS recipients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS statuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS shipments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_code VARCHAR(30) NOT NULL UNIQUE,
    sender_id INT NOT NULL,
    recipient_id INT NOT NULL,
    status_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    weight_kg DECIMAL(8,2) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES senders(id),
    FOREIGN KEY (recipient_id) REFERENCES recipients(id),
    FOREIGN KEY (status_id) REFERENCES statuses(id),
    CHECK (weight_kg > 0)
);

INSERT IGNORE INTO statuses (id, name) VALUES
    (1, 'Қабылданды'),
    (2, 'Жолда'),
    (3, 'Жеткізілді'),
    (4, 'Күтілуде');
