USE parcel_delivery;

INSERT INTO senders (full_name, phone, city) VALUES
    ('Аян Серік', '87010000001', 'Алматы'),
    ('Дана Қуат', '87010000002', 'Астана'),
    ('Ержан Мұрат', '87010000003', 'Шымкент');

INSERT INTO recipients (full_name, phone, address) VALUES
    ('Мадина Әли', '87020000001', 'Алматы, Абылай хан 10'),
    ('Нұржан Бек', '87020000002', 'Астана, Мәңгілік ел 5'),
    ('Аружан Ермек', '87020000003', 'Шымкент, Тәуке хан 15');

INSERT INTO shipments (tracking_code, sender_id, recipient_id, status_id, description, weight_kg) VALUES
    ('KZ-1001', 1, 2, 1, 'Кітап', 1.20),
    ('KZ-1002', 2, 3, 2, 'Киім', 2.50),
    ('KZ-1003', 3, 1, 3, 'Құжат', 0.30);
