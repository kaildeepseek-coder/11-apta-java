package kz.delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RecipientDAO {
    public boolean add(String name, String phone, String address) throws SQLException {
        String sql = "INSERT INTO recipients (full_name, phone, address) VALUES (?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, phone);
            statement.setString(3, address);
            return statement.executeUpdate() > 0;
        }
    }

    public void showAll() throws SQLException {
        show(null);
    }

    public void search(String name) throws SQLException {
        show(name);
    }

    private void show(String name) throws SQLException {
        String sql = "SELECT id, full_name, phone, address FROM recipients";
        if (name != null) {
            sql += " WHERE full_name LIKE ?";
        }
        sql += " ORDER BY id";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (name != null) {
                statement.setString(1, "%" + name + "%");
            }
            try (ResultSet result = statement.executeQuery()) {
                boolean found = false;
                while (result.next()) {
                    found = true;
                    System.out.println(result.getInt("id") + " | "
                            + result.getString("full_name") + " | "
                            + result.getString("phone") + " | "
                            + result.getString("address"));
                }
                if (!found) {
                    System.out.println("Жазба табылмады.");
                }
            }
        }
    }

    public boolean update(int id, String name, String phone, String address) throws SQLException {
        String sql = "UPDATE recipients SET full_name = ?, phone = ?, address = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, phone);
            statement.setString(3, address);
            statement.setInt(4, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM recipients WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}
