package kz.delivery;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ShipmentDAO {
    public boolean add(String trackingCode, int senderId, int recipientId,
                       int statusId, String description, BigDecimal weight) throws SQLException {
        String sql = "INSERT INTO shipments "
                + "(tracking_code, sender_id, recipient_id, status_id, description, weight_kg) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, trackingCode);
            statement.setInt(2, senderId);
            statement.setInt(3, recipientId);
            statement.setInt(4, statusId);
            statement.setString(5, description);
            statement.setBigDecimal(6, weight);
            return statement.executeUpdate() > 0;
        }
    }

    public void showAll() throws SQLException {
        show(null);
    }

    public void search(String text) throws SQLException {
        show(text);
    }

    private void show(String text) throws SQLException {
        String sql = "SELECT sh.id, sh.tracking_code, se.full_name AS sender_name, "
                + "re.full_name AS recipient_name, st.name AS status_name, "
                + "sh.description, sh.weight_kg, sh.created_at "
                + "FROM shipments sh "
                + "JOIN senders se ON sh.sender_id = se.id "
                + "JOIN recipients re ON sh.recipient_id = re.id "
                + "JOIN statuses st ON sh.status_id = st.id";
        if (text != null) {
            sql += " WHERE sh.tracking_code LIKE ? OR sh.description LIKE ?"
                    + " OR se.full_name LIKE ? OR re.full_name LIKE ?";
        }
        sql += " ORDER BY sh.id";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (text != null) {
                for (int i = 1; i <= 4; i++) {
                    statement.setString(i, "%" + text + "%");
                }
            }
            try (ResultSet result = statement.executeQuery()) {
                boolean found = false;
                while (result.next()) {
                    found = true;
                    System.out.println("ID: " + result.getInt("id")
                            + " | Код: " + result.getString("tracking_code")
                            + " | Жіберуші: " + result.getString("sender_name")
                            + " | Алушы: " + result.getString("recipient_name")
                            + " | Мәртебе: " + result.getString("status_name")
                            + " | Сипаттама: " + result.getString("description")
                            + " | Салмақ: " + result.getBigDecimal("weight_kg") + " кг"
                            + " | Күні: " + result.getTimestamp("created_at"));
                }
                if (!found) {
                    System.out.println("Жазба табылмады.");
                }
            }
        }
    }

    public boolean update(int id, String trackingCode, int senderId, int recipientId,
                          int statusId, String description, BigDecimal weight) throws SQLException {
        String sql = "UPDATE shipments SET tracking_code = ?, sender_id = ?, recipient_id = ?, "
                + "status_id = ?, description = ?, weight_kg = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, trackingCode);
            statement.setInt(2, senderId);
            statement.setInt(3, recipientId);
            statement.setInt(4, statusId);
            statement.setString(5, description);
            statement.setBigDecimal(6, weight);
            statement.setInt(7, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM shipments WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}
