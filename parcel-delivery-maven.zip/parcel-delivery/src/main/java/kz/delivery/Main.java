package kz.delivery;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final SenderDAO senderDAO = new SenderDAO();
    private static final RecipientDAO recipientDAO = new RecipientDAO();
    private static final StatusDAO statusDAO = new StatusDAO();
    private static final ShipmentDAO shipmentDAO = new ShipmentDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== СӘЛЕМДЕМЕ ЖЕТКІЗУ ҚЫЗМЕТІ ===");
            System.out.println("1. Жіберушілер");
            System.out.println("2. Алушылар");
            System.out.println("3. Мәртебелер");
            System.out.println("4. Сәлемдемелер");
            System.out.println("0. Шығу");

            int choice = readInt("Таңдау: ");
            switch (choice) {
                case 1 -> senderMenu();
                case 2 -> recipientMenu();
                case 3 -> statusMenu();
                case 4 -> shipmentMenu();
                case 0 -> {
                    System.out.println("Бағдарлама аяқталды.");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Қате таңдау.");
            }
        }
    }

    private static void senderMenu() {
        while (true) {
            printSubMenu("ЖІБЕРУШІЛЕР");
            int choice = readInt("Таңдау: ");
            if (choice == 0) return;

            try {
                switch (choice) {
                    case 1 -> {
                        String name = readText("Аты-жөні: ");
                        String phone = readText("Телефон: ");
                        String city = readText("Қала: ");
                        printResult(senderDAO.add(name, phone, city));
                    }
                    case 2 -> senderDAO.showAll();
                    case 3 -> senderDAO.search(readText("Ізделетін аты: "));
                    case 4 -> {
                        int id = readInt("ID: ");
                        String name = readText("Жаңа аты-жөні: ");
                        String phone = readText("Жаңа телефон: ");
                        String city = readText("Жаңа қала: ");
                        printResult(senderDAO.update(id, name, phone, city));
                    }
                    case 5 -> printResult(senderDAO.delete(readInt("Өшірілетін ID: ")));
                    default -> System.out.println("Қате таңдау.");
                }
            } catch (SQLException e) {
                printError(e);
            }
        }
    }

    private static void recipientMenu() {
        while (true) {
            printSubMenu("АЛУШЫЛАР");
            int choice = readInt("Таңдау: ");
            if (choice == 0) return;

            try {
                switch (choice) {
                    case 1 -> {
                        String name = readText("Аты-жөні: ");
                        String phone = readText("Телефон: ");
                        String address = readText("Мекенжай: ");
                        printResult(recipientDAO.add(name, phone, address));
                    }
                    case 2 -> recipientDAO.showAll();
                    case 3 -> recipientDAO.search(readText("Ізделетін аты: "));
                    case 4 -> {
                        int id = readInt("ID: ");
                        String name = readText("Жаңа аты-жөні: ");
                        String phone = readText("Жаңа телефон: ");
                        String address = readText("Жаңа мекенжай: ");
                        printResult(recipientDAO.update(id, name, phone, address));
                    }
                    case 5 -> printResult(recipientDAO.delete(readInt("Өшірілетін ID: ")));
                    default -> System.out.println("Қате таңдау.");
                }
            } catch (SQLException e) {
                printError(e);
            }
        }
    }

    private static void statusMenu() {
        while (true) {
            printSubMenu("МӘРТЕБЕЛЕР");
            int choice = readInt("Таңдау: ");
            if (choice == 0) return;

            try {
                switch (choice) {
                    case 1 -> printResult(statusDAO.add(readText("Мәртебе атауы: ")));
                    case 2 -> statusDAO.showAll();
                    case 3 -> statusDAO.search(readText("Ізделетін атау: "));
                    case 4 -> {
                        int id = readInt("ID: ");
                        String name = readText("Жаңа атау: ");
                        printResult(statusDAO.update(id, name));
                    }
                    case 5 -> printResult(statusDAO.delete(readInt("Өшірілетін ID: ")));
                    default -> System.out.println("Қате таңдау.");
                }
            } catch (SQLException e) {
                printError(e);
            }
        }
    }

    private static void shipmentMenu() {
        while (true) {
            printSubMenu("СӘЛЕМДЕМЕЛЕР");
            int choice = readInt("Таңдау: ");
            if (choice == 0) return;

            try {
                switch (choice) {
                    case 1 -> {
                        String code = readText("Трек-код: ");
                        int senderId = readInt("Жіберуші ID: ");
                        int recipientId = readInt("Алушы ID: ");
                        int statusId = readInt("Мәртебе ID: ");
                        String description = readText("Сипаттама: ");
                        BigDecimal weight = readWeight();
                        printResult(shipmentDAO.add(code, senderId, recipientId,
                                statusId, description, weight));
                    }
                    case 2 -> shipmentDAO.showAll();
                    case 3 -> shipmentDAO.search(readText("Трек-код, атау немесе сипаттама: "));
                    case 4 -> {
                        int id = readInt("Сәлемдеме ID: ");
                        String code = readText("Жаңа трек-код: ");
                        int senderId = readInt("Жіберуші ID: ");
                        int recipientId = readInt("Алушы ID: ");
                        int statusId = readInt("Жаңа мәртебе ID: ");
                        String description = readText("Жаңа сипаттама: ");
                        BigDecimal weight = readWeight();
                        printResult(shipmentDAO.update(id, code, senderId,
                                recipientId, statusId, description, weight));
                    }
                    case 5 -> printResult(shipmentDAO.delete(readInt("Өшірілетін ID: ")));
                    default -> System.out.println("Қате таңдау.");
                }
            } catch (SQLException e) {
                printError(e);
            }
        }
    }

    private static void printSubMenu(String title) {
        System.out.println("\n=== " + title + " ===");
        System.out.println("1. Қосу (CREATE)");
        System.out.println("2. Барлығын көрсету (READ)");
        System.out.println("3. Іздеу (READ)");
        System.out.println("4. Өзгерту (UPDATE)");
        System.out.println("5. Өшіру (DELETE)");
        System.out.println("0. Артқа");
    }

    private static String readText(String message) {
        while (true) {
            System.out.print(message);
            String text = scanner.nextLine().trim();
            if (!text.isEmpty()) return text;
            System.out.println("Бос енгізуге болмайды.");
        }
    }

    private static int readInt(String message) {
        while (true) {
            System.out.print(message);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Бүтін сан енгізіңіз.");
            }
        }
    }

    private static BigDecimal readWeight() {
        while (true) {
            System.out.print("Салмақ (кг): ");
            try {
                BigDecimal weight = new BigDecimal(scanner.nextLine().trim().replace(',', '.'));
                if (weight.compareTo(BigDecimal.ZERO) > 0) return weight;
            } catch (NumberFormatException e) {
                System.out.println("Қате сан.");
                continue;
            }
            System.out.println("Салмақ 0-ден үлкен болуы керек.");
        }
    }

    private static void printResult(boolean success) {
        System.out.println(success ? "Сәтті орындалды." : "ID табылмады.");
    }

    private static void printError(SQLException e) {
        System.out.println("Деректер қоры қатесі: " + e.getMessage());
    }
}
