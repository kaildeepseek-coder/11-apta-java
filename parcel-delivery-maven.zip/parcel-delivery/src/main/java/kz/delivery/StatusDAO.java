package kz.delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StatusDAO {
    public boolean add(String name) throws SQLException {
        String sql = "INSERT INTO statuses (name) VALUES (?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            return statement.executeUpdate() > 0;
        }
    }

    public void showAll() throws SQLException {
        show(null);
    }

    public void search(String name) throws SQLException {
        show(name);
    }

    private void show(String name) throws SQLException {
        String sql = "SELECT id, name FROM statuses";
        if (name != null) {
            sql += " WHERE name LIKE ?";
        }
        sql += " ORDER BY id";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (name != null) {
                statement.setString(1, "%" + name + "%");
            }
            try (ResultSet result = statement.executeQuery()) {
                boolean found = false;
                while (result.next()) {
                    found = true;
                    System.out.println(result.getInt("id") + " | " + result.getString("name"));
                }
                if (!found) {
                    System.out.println("Жазба табылмады.");
                }
            }
        }
    }

    public boolean update(int id, String name) throws SQLException {
        String sql = "UPDATE statuses SET name = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM statuses WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}
