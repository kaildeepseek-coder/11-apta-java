# Сәлемдеме жеткізу қызметі (№24)

Java және MySQL арқылы жасалған консольдік бағдарлама. Жоба жіберушілерді, алушыларды, сәлемдемелерді және олардың жеткізу мәртебелерін басқарады.

## Технологиялар

- Java 17
- Maven
- MySQL
- JDBC (MySQL Connector/J 9.7.0)
- IntelliJ IDEA

## Деректер қоры

Жоба 4 байланысқан кестеден тұрады.

| Кесте | Өрістер және типтер | Кілттер |
| --- | --- | --- |
| `senders` | `id INT`, `full_name VARCHAR(100)`, `phone VARCHAR(20)`, `city VARCHAR(100)` | `id` — PRIMARY KEY |
| `recipients` | `id INT`, `full_name VARCHAR(100)`, `phone VARCHAR(20)`, `address VARCHAR(255)` | `id` — PRIMARY KEY |
| `statuses` | `id INT`, `name VARCHAR(60)` | `id` — PRIMARY KEY, `name` — UNIQUE |
| `shipments` | `id INT`, `tracking_code VARCHAR(30)`, `sender_id INT`, `recipient_id INT`, `status_id INT`, `description VARCHAR(255)`, `weight_kg DECIMAL(8,2)`, `created_at TIMESTAMP` | `id` — PRIMARY KEY; `tracking_code` — UNIQUE; `sender_id`, `recipient_id`, `status_id` — FOREIGN KEY |

Байланыстар:

- `senders (1) → (N) shipments`
- `recipients (1) → (N) shipments`
- `statuses (1) → (N) shipments`

Басқа кестеде қолданылып тұрған жіберушіні, алушыны немесе мәртебені жоюға MySQL сыртқы кілт арқылы рұқсат бермейді.

## IntelliJ IDEA-да іске қосу

1. **Java 17** және **MySQL Server** орнатыңыз.
2. MySQL Workbench-те `sql/01_schema.sql` файлын ашып, SQL кодын орындаңыз. Бұл деректер қорын, 4 кестені және бастапқы мәртебелерді жасайды.
3. `sql/02_sample_data.sql` файлын **бір рет** орындаңыз. Ол 3 жіберушіні, 3 алушыны және 3 сәлемдемені қосады.
4. IntelliJ IDEA → **Open** → `parcel-delivery` қалтасын таңдаңыз.
5. Maven тәуелділіктері жүктелгенін күтіңіз. Қажет болса, Maven панелінен **Reload All Maven Projects** таңдаңыз.
6. `src/main/java/kz/delivery/DBConnection.java` файлын ашып, MySQL логині мен құпиясөзін өз ортаңызға сәйкес өзгертіңіз:

   ```java
   private static final String URL = "jdbc:mysql://localhost:3306/parcel_delivery?useSSL=false&serverTimezone=UTC";
   private static final String USER = "root";
   private static final String PASSWORD = "";
   ```

7. `src/main/java/kz/delivery/Main.java` → **Run 'Main.main()'**.

Құпиясөзді нақты мәнге өзгерткен болсаңыз, GitHub-қа жарияламас бұрын оны қайтадан бос мәнге ауыстырыңыз. Репозиторийге жеке құпиясөздерді жібермеңіз.

## Консольдік мәзір

Негізгі мәзір:

```text
1. Жіберушілер
2. Алушылар
3. Мәртебелер
4. Сәлемдемелер
0. Шығу
```

Әр бөлімде:

```text
1. Қосу (CREATE)
2. Барлығын көрсету (READ)
3. Іздеу (READ)
4. Өзгерту (UPDATE)
5. Өшіру (DELETE)
0. Артқа
```

Әр операциядан кейін сол бөлімнің мәзірі қайта ашылады.

Сәлемдемені қосқанда алдымен жіберуші, алушы және мәртебе кестесіндегі **ID** мәндерін қолданасыз. Сәлемдемені іздеу трек-код, сипаттама, жіберуші немесе алушының аты бойынша жұмыс істейді.

## CRUD тексеру

`sql/03_crud_test.sql` файлында 4 кестеге де арналған INSERT, SELECT, UPDATE және DELETE сұраныстары бар. Оны MySQL Workbench-те орындауға болады. Сынақ жазбалары соңында өшіріледі, ал `ROLLBACK` транзакцияны кері қайтарады.

Консольде тексеру реті:

1. `4 → 2`: үш бастапқы сәлемдемені көрсету.
2. `4 → 3`: `KZ-1001` коды бойынша іздеу.
3. `4 → 1`: жаңа сәлемдеме қосу (`sender_id=1`, `recipient_id=2`, `status_id=1`).
4. `4 → 4`: жаңа сәлемдеменің ID-ін енгізіп, мәртебесін `2` етіп өзгерту.
5. `4 → 5`: жаңа сәлемдемені ID арқылы жою.
6. `4 → 2`: нәтижені тексеру.

Барлық қолданушы енгізулері `PreparedStatement` арқылы SQL сұранысына беріледі. Деректер қоры ресурстары `try-with-resources` арқылы жабылады, `SQLException` өңделеді.

## Жоба құрылымы

```text
parcel-delivery/
├── pom.xml
├── README.md
├── .gitignore
├── sql/
│   ├── 01_schema.sql
│   ├── 02_sample_data.sql
│   └── 03_crud_test.sql
└── src/main/java/kz/delivery/
    ├── Main.java
    ├── DBConnection.java
    ├── SenderDAO.java
    ├── RecipientDAO.java
    ├── StatusDAO.java
    └── ShipmentDAO.java
```
